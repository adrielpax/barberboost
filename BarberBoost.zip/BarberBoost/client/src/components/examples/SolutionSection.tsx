import SolutionSection from '../SolutionSection'

export default function SolutionSectionExample() {
  return <SolutionSection onCtaClick={() => console.log('Solution CTA clicked')} />
}
