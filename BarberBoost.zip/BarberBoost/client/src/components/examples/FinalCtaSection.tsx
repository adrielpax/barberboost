import FinalCtaSection from '../FinalCtaSection'

export default function FinalCtaSectionExample() {
  return <FinalCtaSection onCtaClick={() => console.log('Final CTA clicked')} />
}
