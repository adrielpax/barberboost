import Header from '../Header'

export default function HeaderExample() {
  return <Header onCtaClick={() => console.log('CTA clicked')} />
}
